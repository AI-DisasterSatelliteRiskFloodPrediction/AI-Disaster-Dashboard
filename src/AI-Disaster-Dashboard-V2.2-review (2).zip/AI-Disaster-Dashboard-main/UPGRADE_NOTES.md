# Upgrade notes — AI Disaster Dashboard V2.1

This is a review build based on the uploaded `AI-Disaster-Dashboard-main.zip`. It has not been pushed to GitHub or deployed.

## Changes in this build
- Preserved the existing portfolio homepage, repository assets, and project structure.
- Added a Flood Intelligence + Action Recommendation Engine to `dashboard.html`.
- Added structured inputs for rainfall reports, water-level trends, observed flooding, exposed people/assets, location, and source.
- Added transparent rule-based screening outcomes and separate guidance for residents and response teams.
- Added reset behaviour, accessible result announcements, responsive layout, and a dedicated `src/flood_intelligence.js` module.
- Corrected the dashboard risk-map image path to match the image file at the repository root.
- Kept demo markers and unsupported metrics explicitly labelled as illustrative or unavailable.

## Important limitations
- The engine uses only values manually entered by a user. It is not a trained AI model and does not calculate a validated flood probability or calibrated risk score.
- No live Sentinel-1/Sentinel-2, Google Earth Engine, rainfall, river-gauge, incident, or emergency-service feed is connected.
- It does not issue public alerts or establish that an area is safe. Official forecasts and authorized emergency instructions take precedence.
- The qualitative rules are a prototype and require review by Rwanda disaster-management, hydrology, and emergency-response specialists before operational use.

## Files changed / added
- `dashboard.html` — new assessment interface and corrected map-image path.
- `style.css` — responsive styling for the new module.
- `src/flood_intelligence.js` — rule-based assessment and recommendation logic.
- Existing `index.html`, `src/flood_detection.js`, assets, and SEO files retained.

## Review and deployment
1. Extract this ZIP and open `dashboard.html` in a modern browser with internet access for the external Leaflet map assets.
2. Try different combinations of the assessment fields and confirm the result wording and recommendations.
3. Review the safety wording and thresholds with qualified local experts before considering operational use.
4. Only after review, replace the corresponding files in the GitHub repository and test the deployed GitHub Pages site on desktop and mobile.
