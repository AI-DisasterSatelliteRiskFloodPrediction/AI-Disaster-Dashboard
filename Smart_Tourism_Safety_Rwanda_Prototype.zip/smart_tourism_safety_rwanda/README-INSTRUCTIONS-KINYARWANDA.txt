SMART TOURISM SAFETY RWANDA — GITHUB INSTALLATION

Iyi ni prototype nshya y'ikarita na dashboard. Ntihindura cyangwa ngo isibe index.html, dashboard.html, style.css cyangwa izindi files zisanzwe.

UKO WAYISHYIRA MURI GITHUB:
1. Fungura repository: https://github.com/AI-DisasterSatelliteRiskFloodPrediction/AI-Disaster-Dashboard
2. Kanda Add file > Upload files.
3. Upload file yitwa tourism-dashboard.html iri muri iyi package.
4. Andika commit message: Add Smart Tourism Safety Rwanda dashboard prototype.
5. Kanda Commit changes.
6. Tegereza GitHub Pages kubaka urubuga, hanyuma ufungure:
   https://ai-disastersatelliteriskfloodprediction.github.io/AI-Disaster-Dashboard/tourism-dashboard.html

IBIRIMO:
- Ikarita ya OpenStreetMap/Leaflet yerekana reference locations enye.
- Guhitamo no kureba destination.
- Form yo kwandika environmental observations.
- Kubika observations muri browser yawe (localStorage).
- Dashboard counters zibarura observations zinjijwe.

LIMITATIONS:
- Iyi version ntabwo ihuza live satellite imagery, live weather, Google Earth Engine API cyangwa AI model.
- Destination pins ni approximate reference points, si hazard polygons.
- Priority yandikwa n'umuntu winjije observation; ntabwo ari AI risk score.
- Ntukoreshe iyi prototype mu gufata ibyemezo by'ubutabazi cyangwa umutekano. Kurikiza amakuru y'inzego zibishinzwe.
- Ikarita ikenera internet kugira ngo ibone OpenStreetMap tiles na Leaflet library.
